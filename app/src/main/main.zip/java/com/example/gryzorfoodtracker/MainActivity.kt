package com.example.gryzorfoodtracker

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.getDatabase(applicationContext)
        val dao = db.mealDao()

        setContent {
            val dynamicColor = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
            val colors = when {
                dynamicColor && isSystemInDarkTheme() -> dynamicDarkColorScheme(LocalContext.current)
                dynamicColor && !isSystemInDarkTheme() -> dynamicLightColorScheme(LocalContext.current)
                isSystemInDarkTheme() -> darkColorScheme()
                else -> lightColorScheme()
            }

            MaterialTheme(colorScheme = colors) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    FoodTrackerScreen(dao)
                }
            }
        }
    }
}

fun getMealIcon(type: String): ImageVector {
    return when (type) {
        "Breakfast" -> Icons.Filled.BakeryDining
        "Lunch" -> Icons.Filled.LunchDining
        "Dinner" -> Icons.Filled.DinnerDining
        "Snack" -> Icons.Filled.Fastfood
        else -> Icons.Filled.Restaurant
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoodTrackerScreen(dao: MealDao) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var editingMeal by remember { mutableStateOf<MealEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val initialPage = Int.MAX_VALUE / 2
    val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { Int.MAX_VALUE })
    val currentDate = remember(pagerState.currentPage) {
        LocalDate.now().plusDays((pagerState.currentPage - initialPage).toLong())
    }
    val currentDayEntries by dao.getMealsForDate(currentDate.toString()).collectAsState(initial = emptyList())
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            LargeDayHeader(
                date = currentDate,
                scrollBehavior = scrollBehavior,
                onPrev = { coroutineScope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) } },
                onNext = { coroutineScope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) } },
                onCopy = { copyToClipboard(context, currentDayEntries, currentDate) }
            )
        },
        floatingActionButton = {
            LargeFloatingActionButton(
                onClick = { editingMeal = null; showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(24.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add Meal", modifier = Modifier.size(32.dp))
            }
        }
    ) { padding ->
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.padding(padding).fillMaxSize()
        ) { page ->
            val pageDate = LocalDate.now().plusDays((page - initialPage).toLong())
            val pageEntries by dao.getMealsForDate(pageDate.toString()).collectAsState(initial = emptyList())

            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {

                // Background Branding
                Image(
                    painter = painterResource(id = R.mipmap.ic_launcher_foreground),
                    contentDescription = null,
                    modifier = Modifier
                        .size(280.dp)
                        .alpha(if (pageEntries.isEmpty()) 0.12f else 0.04f)
                )

                if (pageEntries.isEmpty()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "The day is clear.",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                        )
                        Text(
                            "Tap + to log your first meal.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 100.dp)
                    ) {
                        items(items = pageEntries, key = { it.id }) { entry ->
                            MealCard(
                                entry = entry,
                                onClick = { editingMeal = entry; showAddDialog = true },
                                onDelete = { coroutineScope.launch(Dispatchers.IO) { dao.deleteMeal(entry) } }
                            )
                        }
                    }
                }
            }
        }

        if (showAddDialog) {
            AddMealDialog(
                existingMeal = editingMeal,
                dao = dao,
                onDismiss = { showAddDialog = false },
                onSave = { timeNow, selectedType, text ->
                    coroutineScope.launch(Dispatchers.IO) {
                        if (editingMeal != null) {
                            dao.updateMeal(editingMeal!!.copy(time = timeNow, type = selectedType, description = text))
                        } else {
                            dao.insertMeal(MealEntity(UUID.randomUUID().toString(), currentDate.toString(), timeNow, selectedType, text))
                        }
                    }
                    showAddDialog = false
                },
                onCopyYesterday = { mealType, onResult ->
                    coroutineScope.launch(Dispatchers.IO) {
                        val yesterday = currentDate.minusDays(1).toString()
                        val yesterdayMeals = dao.getMealsForDate(yesterday).first()
                        val match = yesterdayMeals.lastOrNull { it.type == mealType }
                        withContext(Dispatchers.Main) { onResult(match?.description) }
                    }
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LargeDayHeader(date: LocalDate, scrollBehavior: TopAppBarScrollBehavior, onPrev: () -> Unit, onNext: () -> Unit, onCopy: () -> Unit) {
    LargeTopAppBar(
        title = {
            Column {
                Text(
                    text = date.format(DateTimeFormatter.ofPattern("EEEE")),
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = date.format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        },
        navigationIcon = {
            IconButton(onClick = onPrev) { Icon(Icons.Filled.ChevronLeft, "Previous", modifier = Modifier.size(32.dp)) }
        },
        actions = {
            IconButton(onClick = onCopy) { Icon(Icons.Filled.Share, "Share Markdown") }
            IconButton(onClick = onNext) { Icon(Icons.Filled.ChevronRight, "Next", modifier = Modifier.size(32.dp)) }
        },
        scrollBehavior = scrollBehavior,
        colors = TopAppBarDefaults.largeTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.background,
            scrolledContainerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
        )
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MealCard(entry: MealEntity, onClick: () -> Unit, onDelete: () -> Unit) {
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { if (it == SwipeToDismissBoxValue.EndToStart) { onDelete(); true } else false }
    )

    SwipeToDismissBox(
        state = dismissState,
        enableDismissFromStartToEnd = false,
        backgroundContent = {
            val color = if (dismissState.targetValue == SwipeToDismissBoxValue.EndToStart) MaterialTheme.colorScheme.errorContainer else Color.Transparent
            Box(Modifier.fillMaxSize().padding(horizontal = 24.dp), contentAlignment = Alignment.CenterEnd) {
                if (dismissState.targetValue == SwipeToDismissBoxValue.EndToStart) {
                    Icon(Icons.Filled.DeleteSweep, "Delete", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .clickable { onClick() },
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(20.dp).fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Circular Icon Backdrop
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(getMealIcon(entry.type), null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = entry.type.uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = entry.description,
                        style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 22.sp),
                        fontWeight = FontWeight.Medium
                    )
                }

                Text(
                    text = entry.time,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMealDialog(
    existingMeal: MealEntity?,
    dao: MealDao,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit,
    onCopyYesterday: (String, (String?) -> Unit) -> Unit
) {
    val context = LocalContext.current
    var mealText by remember { mutableStateOf(existingMeal?.description ?: "") }
    var selectedMealType by remember { mutableStateOf(existingMeal?.type ?: "Lunch") }
    var mealTime by remember { mutableStateOf(existingMeal?.time ?: LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))) }
    val mealTypes = listOf("Breakfast", "Lunch", "Dinner", "Snack")

    var showTimePicker by remember { mutableStateOf(false) }
    val timePickerState = rememberTimePickerState(
        initialHour = mealTime.split(":")[0].toIntOrNull() ?: LocalTime.now().hour,
        initialMinute = mealTime.split(":")[1].toIntOrNull() ?: LocalTime.now().minute,
        is24Hour = true
    )

    val historicalSuggestions by dao.getSuggestions(selectedMealType).collectAsState(initial = emptyList())
    val filteredSuggestions = historicalSuggestions.filter { it.contains(mealText, ignoreCase = true) && it != mealText }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(32.dp),
            tonalElevation = 6.dp,
            modifier = Modifier.widthIn(max = 400.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = if (existingMeal != null) "Update Entry" else "New Entry",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Time Selection Chip
                AssistChip(
                    onClick = { showTimePicker = true },
                    label = { Text("At $mealTime", style = MaterialTheme.typography.bodyLarge) },
                    leadingIcon = { Icon(Icons.Default.Schedule, null, modifier = Modifier.size(18.dp)) },
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Meal Selection
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(mealTypes) { type ->
                        FilterChip(
                            selected = selectedMealType == type,
                            onClick = { selectedMealType = type },
                            label = { Text(type) },
                            leadingIcon = { Icon(getMealIcon(type), null, modifier = Modifier.size(18.dp)) },
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = mealText,
                    onValueChange = { mealText = it },
                    placeholder = { Text("What are we logging?") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    minLines = 3
                )

                if (filteredSuggestions.isNotEmpty()) {
                    LazyRow(
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredSuggestions) { suggestion ->
                            SuggestionChip(
                                onClick = { mealText = suggestion },
                                label = { Text(suggestion) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { if (mealText.isNotBlank()) onSave(mealTime, selectedMealType, mealText) },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Save Entry")
                    }
                }
            }
        }
    }

    if (showTimePicker) {
        DatePickerDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    mealTime = String.format("%02d:%02d", timePickerState.hour, timePickerState.minute)
                    showTimePicker = false
                }) { Text("OK") }
            }
        ) {
            TimePicker(state = timePickerState, modifier = Modifier.padding(24.dp))
        }
    }
}

fun copyToClipboard(context: Context, entries: List<MealEntity>, date: LocalDate) {
    if (entries.isEmpty()) { Toast.makeText(context, "Nothing to copy!", Toast.LENGTH_SHORT).show(); return }
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val textToCopy = StringBuilder()
    textToCopy.append("**${date.format(DateTimeFormatter.ofPattern("EEE, MMM dd, yyyy"))}**\n\n")
    textToCopy.append("| Time | Type | Description |\n")
    textToCopy.append("| :--- | :--- | :--- |\n")
    entries.forEach { textToCopy.append("| ${it.time} | ${it.type} | ${it.description.replace("|", "")} |\n") }
    clipboard.setPrimaryClip(ClipData.newPlainText("Food Log", textToCopy.toString()))
    Toast.makeText(context, "Copied for Analysis", Toast.LENGTH_SHORT).show()
}