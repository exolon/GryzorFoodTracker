package com.example.gryzorfoodtracker

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "meals")
data class MealEntity(
    @PrimaryKey val id: String,
    val date: String,
    val time: String,
    val type: String,
    val description: String
)

@Dao
interface MealDao {
    @Query("SELECT * FROM meals WHERE date = :targetDate ORDER BY time ASC")
    fun getMealsForDate(targetDate: String): Flow<List<MealEntity>>

    // NEW: Pulls unique previous meals to power the autocomplete suggestions
    @Query("SELECT DISTINCT description FROM meals WHERE type = :mealType ORDER BY date DESC LIMIT 15")
    fun getSuggestions(mealType: String): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertMeal(meal: MealEntity)

    @Update
    fun updateMeal(meal: MealEntity)

    @Delete
    fun deleteMeal(meal: MealEntity)
}

@Database(entities = [MealEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mealDao(): MealDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "food_tracker_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}